package com.company.petsheltercrudservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PetShelterCrudServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
